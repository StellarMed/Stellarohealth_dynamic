# StellarOne Health Live App

A fully working Express.js dynamic app serving static frontend from `dist/`. Ready for Render deployment.

## 🚀 Run Locally

```bash
npm install
npm start
```

Then open [http://localhost:5000](http://localhost:5000)